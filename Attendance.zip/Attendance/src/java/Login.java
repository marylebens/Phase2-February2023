/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Appadmin
 */
@WebServlet(urlPatterns = {"/login"})
public class Login extends HttpServlet {

  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    response.setContentType("text/html;charset=UTF-8");
    try ( PrintWriter out = response.getWriter()) {
      /* TODO output your page here. You may use following sample code. */
      out.println("<!DOCTYPE html>");
      out.println("<html>");
      out.println("<head>");
      out.println("<title>Servlet Login</title>");      
      out.println("</head>");
      out.println("<body>");
      out.println("<h1>Servlet Login at " + request.getContextPath() + "</h1>");
      out.println("</body>");
      out.println("</html>");
    }
  }


  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    processRequest(request, response);
  }


  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    try{
      String driver="com.mysql.cj.jdbc.Driver";
      String email=request.getParameter("email");
      //session.putValue("email",email); 
      String password=request.getParameter("password");
      //create a new DAO object
      AttendanceDAO loginDAO=new AttendanceDAO();
      loginDAO.loadDriver(driver);  //load jdbc driver
      loginDAO.getConnect();  //connect to the database
      Connection con=loginDAO.getConnect();
      
      Statement stmt=con.createStatement(); //create a statement instance
      ResultSet rs=stmt.executeQuery("SELECT email, password FROM users "
              + "WHERE email='"+email+"' AND password='"+password+"';");
      while(rs.next()){
        
      //option 1
      if(rs.getString("email").equals(email) && rs.getString("password").equals(password)){
        //response.getWriter().print("Login Successful");
        out.println("Login Successful");
        //response.putValue("email", email);
        response.sendRedirect(response.encodeRedirectURL("instructor.jsp"));
      } else {
         //out.print("Unsuccessful Attempt Try again");
        //response.getWriter().print("Unsuccessful Attempt Try Again");
        //response.getWriter().print("<h2>Failed Login Attempt</h2>");
        
        //If you want to include a JSP in the generated response, use
        //request.getRequestDispatcher("failedLogin.jsp").include(request, response);
        
        //If you want to forward to that jsp, use
        request.getRequestDispatcher("/failedLogin.jsp").forward(request, response);
        
      }//end if-else
      break;
    } //end while
    }catch(Exception e){
      e.printStackTrace();
    }//end try-catch 
    //processRequest(request, response);
  }//end doPost 
    
  

  @Override
  public String getServletInfo() {
    return "Short description";
  }// </editor-fold>

}
