/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import com.DBConnection;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author Appadmin
 */
@WebServlet(urlPatterns = {"/UpdateStudent"})
@MultipartConfig(maxFileSize = 16177215)    // upload file's size up to 16MB
public class UpdateStudent extends HttpServlet {


  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    response.setContentType("text/html;charset=UTF-8");
    try ( PrintWriter out = response.getWriter()) {
      /* TODO output your page here. You may use following sample code. */
      out.println("<!DOCTYPE html>");
      out.println("<html>");
      out.println("<head>");
      out.println("<title>Servlet UpdateStudent</title>");      
      out.println("</head>");
      out.println("<body>");
      out.println("<h1>Servlet UpdateStudent at " + request.getContextPath() + "</h1>");
      out.println("</body>");
      out.println("</html>");
    }
  }


  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    processRequest(request, response);
  }

  
  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    
      try{ 
        //connect to database using getConnection method in the DBConnection class
        DBConnection dbaccess=new DBConnection();
        Connection con=dbaccess.getConnection();
       
      int user_id=Integer.parseInt(request.getParameter("user_id"));
      int student_id=Integer.parseInt(request.getParameter("student_id"));
      int program_id=Integer.parseInt(request.getParameter("program_id"));
      int participation_id=Integer.parseInt(request.getParameter("participation_id"));
      
      String firstname=request.getParameter("firstname");
      String lastname=request.getParameter("lastname");
      String parentsemail=request.getParameter("email");
      String parentsphone=request.getParameter("phone");
      String remarks=request.getParameter("remarks");
      
      //Receive date as strings from form using java.util.Date package
      java.util.Date selectedcheckin = new SimpleDateFormat("hh:mm:ss").parse(request.getParameter("checkIn"));
      java.sql.Time checkIn =  new java.sql.Time(selectedcheckin.getTime());
      java.util.Date selectedcheckout = new SimpleDateFormat("hh:mm:ss").parse(request.getParameter("checkout"));
      java.sql.Time checkout =  new java.sql.Time(selectedcheckout.getTime());
      
      //Recive and process images
      Part filepart=request.getPart("image");
      String filename=Paths.get(filepart.getSubmittedFileName()).getFileName().toString(); //access method in             Part to obtain filename
      //update filename to student's lastname
      filename=lastname.toLowerCase()+".jpg";

      String Uploadpath="C:/Users/Appadmin/Documents/NetBeansProjects/Attendance/web/images/students/"+filename;
      //Use File InputStream and OutPutStreams to copy the file to new location: Uplaodpath
      InputStream filecontent=filepart.getInputStream();
      FileOutputStream fos=new FileOutputStream(Uploadpath);
      byte[] data=new byte[filecontent.available()];
      filecontent.read(data);
      fos.write(data);
      fos.close();    //close FileOutputStream use from copying imagefile
    
      
      //Update student table
      String sql="SELECT * FROM students WHERE student_id='"+student_id+"';";
        //try cascade on delete by setting constrain in the database.
        Statement stmt=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        ResultSet rs=stmt.executeQuery(sql);
        
        if(rs.next()){
          rs.updateString("firstname", firstname);
          rs.updateString("lastname", lastname);
          rs.updateString("image", filename);
          rs.updateRow();
          //rs.close();
        }
        
        //Update participation table
        sql="SELECT * FROM participation "
                + "WHERE participation_id='"+participation_id+"' "
                + "AND student_id='"+student_id+"';";
        rs=stmt.executeQuery(sql);
        if(rs.next()){
          rs.updateTime("checkIn", checkIn);
          rs.updateTime("checkout", checkout);
          rs.updateString("remarks", remarks);
          rs.updateRow();
          //rs.close();
        }
        //Update parents phone/email in users table
        sql="SELECT * FROM users WHERE user_id='"+user_id+"';";
        rs=stmt.executeQuery(sql);
        if(rs.next()){
          rs.updateString("email", parentsemail);
          rs.updateString("phone", parentsphone);
          rs.updateRow();
          //rs.close();
        }
          out.print("UPDATE Successfully");
          //RequestDispatcher dispatcher = request.getRequestDispatcher("instructor.jsp");
          //dispatcher.forward(request, response);
          response.sendRedirect("instructor.jsp");
  }catch(Exception e){
    e.printStackTrace();
  }//end try-catch
    //processRequest(request, response);
    
  }//End doPost()


  @Override
  public String getServletInfo() {
    return "Short description";
  }// </editor-fold>

}
