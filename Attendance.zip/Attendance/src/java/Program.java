/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import static java.lang.System.out;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;


@WebServlet(urlPatterns = {"/Program"})
@MultipartConfig(maxFileSize = 16177215)    // upload file's size up to 16MB
public class Program extends HttpServlet {
  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
  
  
    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rollcall", "root", "admin");
      int user_id=Integer.parseInt(request.getParameter("user_id"));
      String theme=request.getParameter("theme");
      String description=request.getParameter("description");
      Part filepart=request.getPart("image");

      //Receive date as strings from form using java.util.Date package
      java.util.Date selectedstartDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("startDate")); 
      java.util.Date selectedstartTime = new SimpleDateFormat("HH:mm").parse(request.getParameter("startTime")); 
      java.util.Date selectedendDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("endDate")); 
      java.util.Date selectedendTime = new SimpleDateFormat("HH:mm").parse(request.getParameter("endTime"));
      //Convert util.Date to sql.Date acceptable by jdbc for mysql database
      java.sql.Date startDate =  new java.sql.Date(selectedstartDate.getTime());
      Time startTime =  new java.sql.Time(selectedstartTime.getTime());
      java.sql.Date endDate =  new java.sql.Date(selectedendDate.getTime());
      java.sql.Time endTime =  new java.sql.Time(selectedendTime.getTime());


     /* String inputStart=request.getParameter("startTime");
      //String inputEnd=request.getParameter("end");
      System.out.println("Formatted Selected startDate: "+selectedstartDate+"."
              + "startTime: "+selectedstartTime+"\n"
                      + "Unformatted startTime: "+inputStart);
      */
      //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");  
      //LocalDateTime date1 = LocalDateTime.parse(inputStart);
      //LocalDateTime date2 = LocalDateTime.parse(inputEnd);
      //LocalDateTime date2 = LocalDateTime.parse(inputEnd, format);
      //Converting date and time values from local to SQL
      //java.sql.Date startDate = java.sql.Date.valueOf(date1.format(formatter));
      //java.sql.Date start = java.sql.Date.valueOf(date1.format(formatter));
      //java.sql.Date end = java.sql.Date.valueOf(date2.format(formatter));
      
      
      String image=Paths.get(filepart.getSubmittedFileName()).getFileName().toString();
      //Rename image using random number
      double i=Math.random();
      int rand=(int)i*50;
      image="theme_image"+i+".jpg"; //creates a new name incrementing number if exists
      System.out.println(image);
      String uploadpath="C:/Users/Appadmin/Documents/NetBeansProjects/Attendance/web/images/program/"+image;
      //Use File InputStream and OutPutStreams to copy the file to new location: Uplaodpath
      InputStream filecontent=filepart.getInputStream();
      FileOutputStream fos=new FileOutputStream(uploadpath);
      
      byte[] data=new byte[filecontent.available()];
      filecontent.read(data);
      fos.write(data);
      fos.close();
            
      
      String sql = "INSERT INTO program (user_id,theme,description,startDate,endDate,image,startTime,endTime) "
              + "VALUES(?,?,?,?,?,?,?,?);";
      PreparedStatement ps=con.prepareStatement(sql);

      ps.setInt(1, user_id);
      ps.setString(2, theme);
      ps.setString(3, description);
      ps.setDate(4,  startDate); //cast date to 
      ps.setDate(5,  endDate); //java.sql.Date      
      ps.setString(6, image);
      ps.setTime(7, startTime);
      ps.setTime(8, endTime);
      
      int row=0;
          row=ps.executeUpdate();
          
      //Query program table and retreve new program_id and sent to instructor.jsp
      //it will be used to register students into participation
      String proSql="SELECT * FROM program WHERE user_id='"+user_id+"';";
      Statement stmt=con.createStatement();
      ResultSet rs=stmt.executeQuery(proSql);
      
      while(rs.next()) {
        if(row>0){
          int program_id=rs.getInt("program_id");

            request.setAttribute("program_id", program_id);
            //request.setAttribute("user_id", user_id);
            //request.getSession(false).setAttribute("program_id", program_id);
            //request.getSession(false).setAttribute("user_id", user_id);
            //response.addIntHeader("program_id", program_id);

            System.out.println("program_id"+program_id);

            //RequestDispatcher dispatcher = request.getRequestDispatcher("instructor.jsp");
            //dispatcher.forward(request, response);
        }else {
            //response.sendRedirect("instructor.jsp?status=error");
            System.out.println("Error creating program");
        }
      }//end while
        
            response.sendRedirect("instructor.jsp");
      
        } catch (ClassNotFoundException ex) {
          ex.printStackTrace();
        } catch (SQLException ex) {
          ex.printStackTrace();
        //} catch (ParseException ex) {
        //Logger.getLogger(Program.class.getName()).log(Level.SEVERE, null, ex);
    } catch (ParseException ex) {
      Logger.getLogger(Program.class.getName()).log(Level.SEVERE, null, ex);
    }//end try-catch

      }//end doPost
  
  //method to verify new program created and will be used to get its id then 
  //sent to AddStudent.java for registration in to participation table
  public static String programCheck(ProgramBean programbean){
  try{
    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con=DriverManager.getConnection("jdbc:mysqsl://localhost:3306/rollcall", "root", "admin");
    String sql="SELECT * FROM program WHERE user_id=? and program_id=?";
    PreparedStatement ps=con.prepareStatement(sql);
    ps.setInt(1, programbean.getUser_id());
    ps.setInt(2, programbean.getProgram_id());
    ResultSet rs=ps.executeQuery();
    
    if(rs.next()){
      return "true";
    } else {
      return"false";
    }//end if-else
  }catch(Exception e) {
    e.printStackTrace();
  }//end try-catch block
  return "Error";
  }//end programCheck

  
}//end Servlet
