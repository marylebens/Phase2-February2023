
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
//import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


/**
 *
 * @author Appadmin
 */
@WebServlet(urlPatterns = {"/createAccount"})
@MultipartConfig                                   //Annotation to use with multipart/form-data  
public class Attendance extends HttpServlet {


  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    try {
      //Receive form data from their name attrivutes
      String firstname=request.getParameter("firstname");
      String lastname=request.getParameter("lastname");
      String email=request.getParameter("email");
      String password=request.getParameter("password");
      String phone=request.getParameter("phone");
      boolean isInstructor=Boolean.parseBoolean(request.getParameter("isInstructor"));
      Part imagepart=request.getPart("image");  //Recieve request from form using Part Class
      String image=Paths.get(imagepart.getSubmittedFileName()).getFileName().toString(); //get File name
      
      //replace trailing and leading spaces in form records to prevent errors
      firstname.replaceAll("\\s", "");       lastname.replaceAll("\\s", "");
      email.replaceAll("\\s", "");           password.replaceAll("\\s", "");
      phone.replaceAll("\\s", "");           image.replaceAll("\\s", "");
      //Update Filename to usernames
      image=firstname+"_"+lastname+".jpg";
      //Set Destination Dir
      String uploadpath="C:/Users/Appadmin/Documents/NetBeansProjects/Attendance/web/images/users/"+image;
      
      //Use File InputStream and OutPutStreams to copy the file to new location: Uplaodpath
      InputStream filecontent=imagepart.getInputStream();
      FileOutputStream fos=new FileOutputStream(uploadpath);
      byte[] data=new byte[filecontent.available()];
      filecontent.read(data);
      fos.write(data);
      fos.close();

      //veriry image file name with print out statment
      if(image!=null){
      System.out.println("Image Selected File Name: "+ image);
        System.out.println("Upload Path is: "+ uploadpath);
      } else {
        System.out.println("NullPointer Exception");
        response.getWriter().print("Error Uploading file: ");
      }
    
      //SimpleDateFormat ft=new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
      //String dateCreated=request.getParameter("created");
      Date date=new Date();
      java.sql.Date created=new java.sql.Date(date.getTime());
      
      //TimeStamp created=TimeStamp.(request.getParameter("created"));
      //Date created=(Date) new SimpleDateFormat("yyyy-mm-dd hh:mm:ss").parse(request.getParameter("created"));
      //Date login=(Date) new SimpleDateFormat("HH:MM:SS").parse(request.getParameter("login"));
      
      //create new user object
      User user=new User(firstname,lastname,email,password,phone,image,created,isInstructor);
      AttendanceDAO userDao=new AttendanceDAO();
      String result=userDao.createUser(user);
      //response.getWriter().print(result);
      
      //If account is created Login and go to dashboard
      if(result!=null){
        //session.setAttribute("email",user.getEmail());
        request.getSession(false).setAttribute("email", user.getEmail());
        response.sendRedirect(response.encodeRedirectUrl("login.jsp"));
        }

        if(result.equals("false")){
        response.sendRedirect("login.jsp?status=false");
        }

        if(result.equals("error")){
            response.sendRedirect("login.jsp?status=error");
        }
    }catch (SQLException e) {
      e.printStackTrace();
    }//end try-catch
  }//End doPost

 
  
  @Override
  public String getServletInfo() {
    return "Short description";
  }// </editor-fold>

}
