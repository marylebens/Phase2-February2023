
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AttendanceDAO {
  private String dburl="jdbc:mysql://localhost:3306/rollcall";
  private String dbuname="root";
  private String dbpassword="admin";
  private String dbDriver="com.mysql.cj.jdbc.Driver";
  private Connection conn;
  
  //load jdbc driver
  public void loadDriver(String jdbcdriver) {
    try {
      Class.forName(dbDriver);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }//end loadDriver method
  
  //Add disconnection method
    public void disconnect() throws SQLException {
        if (conn!=null && !conn.isClosed()) {
            conn.close();
        }
    }//End disconnect method
  
  //Creat Connection method to the database
  public Connection getConnect() throws SQLException{
     if (conn == null || conn.isClosed()) {
     try {
       conn=DriverManager.getConnection(dburl,dbuname,dbpassword);
     }catch(SQLException e){
       e.printStackTrace();
     }//end try-catch blockp[=
     }//end if
     return conn;
  }//end getConnect() method
  
  
  public String createUser(User user) throws SQLException{
    loadDriver(dbDriver);
    Connection con=getConnect();
    String message="User Account Created";
    String query="INSERT INTO rollcall.users (firstname,lastname,email,password,phone,image,created,isInstructor) "
            + "VALUES(?,?,?,?,?,?,?,?);";
    try {
      PreparedStatement ps=con.prepareStatement(query);
      //pass values into query placeholders by calling getters from User class
      ps.setString(1, user.getFirstname());
      ps.setString(2, user.getLastname());
      ps.setString(3, user.getEmail());
      ps.setString(4, user.getPassword());
      ps.setString(5, user.getPhone());
      ps.setString(6, user.getImage());      
      ps.setDate(7, user.getCreated());
      ps.setBoolean(8, user.getIsinstructor());
      
      
      //update the database
      ps.executeUpdate();
      
      }catch (SQLException e) {
        e.printStackTrace();
        message="Data not entered";
      }//end try-catch block
    return message;
    
  }//End createUser
  
        
      public String userLogin(User user) throws SQLException, ClassNotFoundException{
      loadDriver(dbDriver);
      Connection con=getConnect(); //commented out because of static status in userLogin
      //Class.forName("com.mysql.cj.jdbc.Driver");
      //Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rollcall", "root", "admin");
      //query before login
      String loginQ = "SELECT * FROM users WHERE email=? AND password=?";
      try {
             
      PreparedStatement pstmt = con.prepareStatement(loginQ);
      pstmt.setString(1, user.getEmail());
      pstmt.setString(2, user.getPassword());
      
      //Use resultset to fetch info with respect to paramenters
      ResultSet rs = pstmt.executeQuery();
      
      if(rs.next()){
        return "true";
      } else{
        return "false";
      }//end if-else
      
      }catch(SQLException e){
      e.printStackTrace();
      }//end try-catch block
       return "error";
  }//End userLogin method 
  
}//end AttendanceDAO
