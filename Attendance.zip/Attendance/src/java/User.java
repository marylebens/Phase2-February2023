

import java.sql.Date;

public class User {
  private String firstname, lastname, email, password, phone, image;
  private Date created, updated;
  private Date login, logout;
  private boolean isInstructor;

  public User() {
  }//End default constructor

  public User(String email, String password) {
    this.email = email;
    this.password = password;
  }//End constructor: email, password

  public User(String firstname, String lastname, String email, String password) {
    this.firstname = firstname;
    this.lastname = lastname;
    this.email = email;
    this.password = password;
  }
  
  public User(String firstname, String lastname, String email, String password, String phone, Date created, boolean isInstructor) {
    this.firstname = firstname;
    this.lastname = lastname;
    this.email = email;
    this.password = password;
    this.phone = phone;
    this.created = created;
    this.isInstructor = isInstructor;
  }
  
  public User(String firstname, String lastname, String email, String password, String phone, String image, Date created, boolean isInstructor) {
    this.firstname = firstname;
    this.lastname = lastname;
    this.email = email;
    this.password = password;
    this.phone = phone;
    this.image = image;
    this.created = created;
    this.isInstructor = isInstructor;
  }
  
    
  
  //Getters and Setters

  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public String getLastname() {
    return lastname;
  }

  public void setLastname(String lastname) {
    this.lastname = lastname;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getImage() {
    return image;
  }

  public void setImage(String image) {
    this.image = image;
  }
  //Ensure date created is current and local
  public Date getCreated() {
    /*
    DateFormatter dtf = DateFormatter.ofPattern("MMMM dd, yyyy HH:mm:ss");
    Date now = Date.now();
    System.out.print(dtf.format(now)); */
    return created;
  }

  public void setCreated(Date created) {
    this.created = created;
  }

  public Date getUpdated() {
    return updated;
  }

  public void setUpdated(Date updated) {
    this.updated = updated;
  }

  public Date getLogin() {
    return login;
  }

  public void setLogin(Date login) {
    this.login = login;
  }

  public Date getLogout() {
    return logout;
  }

  public void setLogout(Date logout) {
    this.logout = logout;
  }

  public boolean getIsinstructor() {
    return isInstructor;
  }

  public void setIsInstructor(boolean isInstructor) {
    this.isInstructor = isInstructor;
  }
  //End Getters and Setters
  
}//end User class
