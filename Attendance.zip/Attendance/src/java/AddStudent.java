/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.nio.file.Paths;
//java.lang.NullPointerException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;



@WebServlet(urlPatterns = {"/addStudent"})
@MultipartConfig                                        //Annotation to use with multipart/form-data
public class AddStudent extends HttpServlet {

public AddStudent() {
    super();
}
  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    response.setContentType("text/html;charset=UTF-8");
    try ( PrintWriter out = response.getWriter()) {
      /* TODO output your page here. You may use following sample code. */
      out.println("<!DOCTYPE html>");
      out.println("<html>");
      out.println("<head>");
      out.println("<title>Servlet AddStudent</title>");      
      out.println("</head>");
      out.println("<body>");
      out.println("<h1>Servlet AddStudent at " + request.getContextPath() + "</h1>");
      out.println("</body>");
      out.println("</html>");
    }
  }


  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    //processRequest(request, response);
    response.getWriter().append("Served at: ").append(request.getContextPath());
  }

    // https://dotnettutorials.net/lesson/file-uploading-downloading-jsp/
  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException, NullPointerException {
  
    try {
    
    String Driver="com.mysql.cj.jdbc.Driver";
    AttendanceDAO studentDAO=new AttendanceDAO();
    studentDAO.loadDriver(Driver);
    Connection con=studentDAO.getConnect();
    
    int user_id=Integer.parseInt(request.getParameter("user_id"));
    String firstname=request.getParameter("firstname");
    String lastname=request.getParameter("lastname");
    String createdByemail=request.getParameter("createdByemail");
    int program_id=Integer.parseInt(request.getParameter("program_id"));
    //set up checkin time according to time of student registration at this time
    Date now=new java.util.Date(); //date is epoch time but time is based on locale system time
    java.sql.Time checkIn=new java.sql.Time(now.getTime());
    
    Part filepart=request.getPart("image");  //Use Part class to receive request from client
    String filename=Paths.get(filepart.getSubmittedFileName()).getFileName().toString(); //access method in             Part to obtain filename
    //update filename to student's lastname
    filename=lastname.toLowerCase()+".jpg";

    String Uploadpath="C:/Users/Appadmin/Documents/NetBeansProjects/Attendance/web/images/students/"+filename;
    //Use File InputStream and OutPutStreams to copy the file to new location: Uplaodpath
    InputStream filecontent=filepart.getInputStream();
    FileOutputStream fos=new FileOutputStream(Uploadpath);
    byte[] data=new byte[filecontent.available()];
    filecontent.read(data);
    fos.write(data);
    fos.close();    //close FileOutputStream use from copying imagefile
    
    
    String insertStudent="INSERT INTO students (user_id, firstname, lastname, createdby, image) "
            + "VALUES(?,?,?,?,?);";
    PreparedStatement student=con.prepareStatement(insertStudent, Statement.RETURN_GENERATED_KEYS);
    student.setInt(1, user_id);
    student.setString(2, firstname);
    student.setString(3, lastname);
    student.setString(4, createdByemail);
    student.setString(5, filename);
    

    //Verify student record is registered in database and send redirect response
    //back to instructor dashboard
    int status=0;
        status=student.executeUpdate();
    //if(status!=0){
    if(status>0){
    ResultSet rs=student.getGeneratedKeys();
    int generatedKey = 0; 
    if (rs.next()) {
        generatedKey = rs.getInt(1);
        System.out.println("Inserted record's ID: " + generatedKey);
    }// use autogenerated key to get student id which is primary key them update 
    //participation table to complete student registration
    
      
      //Register student for participation by creating new record in participation
    //table using query from users and program tables sent to addStudent Servlet
    String registerStudent="INSERT INTO participation(student_id,program_id,checkIn) "
            + "VALUES(?,?,?);";
    
    PreparedStatement registeredStudent=con.prepareStatement(registerStudent);
    registeredStudent.setInt(1, generatedKey);
    registeredStudent.setInt(2, program_id);
    registeredStudent.setTime(3, checkIn);
    registeredStudent.executeUpdate();
    int new_row=0;
    String registered="Registered";
    if (new_row>0){
      request.setAttribute("registered", registered);
      System.out.println("SUCCESSFULLY Registered");
    }//end if is registered
    
    }//end if student added and registered
    
        //veriry image file name with print out statment
    if(filename!=null){
      //response.getWriter().print("Image Selected File Name: "+ filename);
    System.out.println("Image Selected File Name: "+ filename);
      System.out.println("Upload Path is: "+ Uploadpath);
    } else {
      System.out.println("Error Uploading Image");
    }//end if imagefile validation
    

    } catch (SQLException ex) {
      ex.printStackTrace();
    } catch (Exception e) {
        e.printStackTrace();
    }finally{
            //response.sendRedirect(response.encodeRedirectURL("instructor.jsp"));
            response.sendRedirect("instructor.jsp");
    }//end try-catch-catch-finally Error handling

    }//end doPost

    @Override
    public String getServletInfo() {
      return "Short description";
    } // </editor-fold>
  }//end servlet
